stateMachine
============

A feature-rich, yet simple finite state machine (FSM) implementation in C.

For when a simple switch statement just isn't enough. [Documentation](http://misje.github.io/stateMachine).
